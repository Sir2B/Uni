#!/usr/bin/python3

import numpy as np
from sys import exit, stdout
from matplotlib import pyplot as plt


if __name__ == "__main__":

    xxx = np.arange(0, 3, 0.01)
    f = lambda x: np.cos(x**2 + 0.5 + np.sqrt(x)) * 0.9 * x + 1.2
    data = f(xxx)


    plt.plot(xxx, data)
    plt.show()

    stdout.write("\n".join([str(v) for v in data]))
    stdout.write("\n")



    
    exit(0)
