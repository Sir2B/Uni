#include <iostream>
#include <ostream>
#include <valarray>
#include <vector>

using std::ostream;
using std::cout;
using std::cin;



class Teilchen
{
    public:
        double mass=0; // masse Teilchen
        std::string name=""; // Name Teilchen
        double Anzahl_Kompontenten=1; // Anzahl komponenten
        double m=0; // Summe masse einzelteilchen
        double DE=0; // Energiedifferenz
        std::string komponenten=""; // Liste der Komponenten
    
        void set_mass(const double & ma)
        {
            mass=ma;
            if (Anzahl_Kompontenten>1)
            {
                DE=mass-m; //Berechnung Energiedifferenz
            }
        };
    
        void set_name(const std::string & n)
        {
            name=n;
        };
    
        void add_component(const Teilchen & T)
        {
            m += T.mass; // update masse
            komponenten += T.name; // update komponentenliste
            komponenten += "  ";
            Anzahl_Kompontenten += 1; // update anzahl komponenten
            
            
        };

        void print_properties()
        {
        
            cout << "\n" << "-----------------------------------" << "\n";
            cout << name << "\n"; //printe name
            cout << "-----------------------------------" << "\n" << "\n";
            if (Anzahl_Kompontenten>1) // Printe Energiedifferenz und Komponenten
            {
                cout << "Komponenten: " << "\n" << komponenten << "\n";
                cout << "DE=" << DE << " MeV" << "\n";
            }
            
            cout << "Masse=" << mass << " MeV/c^2" << "\n" ; //printe Masse
            
        };

};

