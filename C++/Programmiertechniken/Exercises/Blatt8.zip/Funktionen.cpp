


std::string find_kind (const double & q)
{
    if ((q==-1 or q==0) and Anzahl_Kompontenten==1) //bedingungen fuer lepton
    {
        kindm="Lepton";
    }
    else if ((q==-1./3. or q==2./3.) and Anzahl_Kompontenten==1)//bedingungen fuer quark
    {
        kindm="Quark";
    }
    else
    {
        kindm="Unbekannt"; // unbekanntes Teilchen
    }
    return kindm;
}



// Input Single_Particle

Teilchen_Q input()
    {
        cout << "Name ";
        cin >> name;
        cout << "Masse ";
        cin >> masse;
        cout << "Ladung*3 "; //Der Faktor 3 ist noetig, weil man bei cin keine Brueche eingeben kann.
        cin >> ladung;
        
        
        T.set_name(name);
        T.set_charge(ladung/3); //Der Faktor 3 ist noetig, weil man bei cin keine Brueche eingeben kann.
        T.set_mass(masse);
        
        return T;
    }


// Input Baryon

Teilchen_Q input()
    {
        cout << "Name Baryon ";
        cin >> Name_Bar;
        cout << "\n" << "Masse Baryon ";
        cin >> Masse_Bar;
        T.set_name(Name_Bar);
        for (int i=0; i<3; i++)
        {
            cout << "Quark " << i+1 << "\n" << "------------------------------" << "\n";
            cout << "\n" << "Name ";
            cin >> name;
            cout << "\n" << "Masse ";
            cin >> masse;
            cout << "\n" << "Ladung*3 "; //Der Faktor 3 ist noetig, weil man bei cin keine Brueche eingeben kann.
            cin >> ladung;
            
            quark.set_name(name);
            quark.set_charge(ladung/3); //Der Faktor 3 ist noetig, weil man bei cin keine Brueche eingeben kann.
            
            quark.set_mass(masse);
            T.add_component(quark);
        }
        T.set_mass(Masse_Bar);
        return T;
    }




