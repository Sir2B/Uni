

/* A first C++ program */
#include <iostream>

using namespace std;		// also valid: using std::cout

int main() {
  cout << "Welcome students!\n";
  std::cout << "Hello world!" << std::endl;     // this notation works without "using"
                                                // never use the "using" keyword globally in libraries
  return 0;
}



