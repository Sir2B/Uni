


#include <iostream>
using namespace std;

int main() {
  int a=0; 
  std::cout << a++ << "\n";
  std::cout << ++a << "\n";
  std::cout << a << "\n";
  


  return 0;
}
