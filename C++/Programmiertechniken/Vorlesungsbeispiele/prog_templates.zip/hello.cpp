


#include <iostream>

int main() {
  std::string s = "Hello, world!";
  std::cout << s << "\n";	// standard example of ADL
}
