#include "ex_inline.hpp"

int main() {
  int x = 4;
  int y = incr(x);
  return 0;
}
