


// preproc4.cpp

#include "preproc4.h"
#include "preproc4.h"			// compiles

int main() {
  cmpl MycomplexNumber;
}
