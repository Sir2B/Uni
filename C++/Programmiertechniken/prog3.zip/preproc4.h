


#ifndef GUARD_PREPROC4
#define GUARD_PREPROC4

// preproc4.h header file

struct cmpl {
  double real_;
  double imag_;
};

#endif


