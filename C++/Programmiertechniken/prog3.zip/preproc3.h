


// preproc3.h header file

struct cmpl {
  double real_;
  double imag_;
};



