


// preproc3.cpp

#include "preproc3.h"

int main() {
  cmpl MycomplexNumber;
}
